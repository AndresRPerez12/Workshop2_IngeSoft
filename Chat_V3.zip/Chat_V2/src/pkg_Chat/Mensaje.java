
package pkg_Chat;

import java.awt.Color;
import java.util.Random;

public class Mensaje {
    Persona p;
    String texto;
    Color color;

    public Mensaje(Persona p, String texto) {
        Random rand = new Random();
        this.p = p;
        this.texto = texto;
        float r = rand.nextFloat();
        float g = rand.nextFloat();
        float b = rand.nextFloat();
        this.color = new Color(r, g, b);
    }
    
    public String toString(){
        String ret = p.nombre + ": " + texto;
        return ret;
    }
    
}
