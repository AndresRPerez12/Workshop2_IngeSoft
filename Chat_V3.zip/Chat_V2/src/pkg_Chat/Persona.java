/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg_Chat;

import java.awt.Color;
import java.util.Random;

/**
 *
 * @author andre
 */
public class Persona {
    String nombre;
    Color color;
    
    public Persona( String nombre ){
        this.nombre = nombre;
        Random rand = new Random();
        float r = rand.nextFloat();
        float g = rand.nextFloat();
        float b = rand.nextFloat();
        this.color = new Color(r, g, b);
    }
}
